import React from 'react';
import Home from './components/Home';
import './App.css'; // if you have app styles

function App() {
  return (
    <div className="App">
      <Home />
    </div>
  );
}

export default App;